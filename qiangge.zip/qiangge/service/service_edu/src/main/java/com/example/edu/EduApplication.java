package com.example.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan(basePackages = {"com.example",})//TODO swagger没有出效果，等待解决
public class EduApplication {
    public static void main(String[] args){

        SpringApplication.run(EduApplication.class, args);
    }
}
