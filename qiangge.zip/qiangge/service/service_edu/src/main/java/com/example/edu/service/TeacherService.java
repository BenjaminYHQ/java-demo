package com.example.edu.service;

import com.example.edu.entity.Teacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * è®²å¸ˆ 服务类
 * </p>
 *
 * @author testjava
 * @since 2020-07-27
 */
public interface TeacherService extends IService<Teacher> {


}
