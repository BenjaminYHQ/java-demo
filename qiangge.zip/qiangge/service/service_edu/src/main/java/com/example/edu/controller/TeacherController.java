package com.example.edu.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.commonutils.R;
import com.example.edu.entity.Teacher;
import com.example.edu.entity.vo.TeacherQuery;
import com.example.edu.service.TeacherService;
import com.example.servicebase.handle.exceptionhandler.QianggeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author testjava
 * @since 2020-07-27
 */
@RestController
@RequestMapping("/edu/teacher")
@CrossOrigin  //解决跨域问题
public class TeacherController {
    @Autowired  //把service注入
    private TeacherService teacherService;
    //rest风格
    //查询表中所有数据
    @GetMapping("findAll")
    public R findAllTeacher(){
        List<Teacher> list = teacherService.list(null);
        return R.ok().data("items", list);
    }

    //删除讲师
    @DeleteMapping("{id}")
    public R deleteTeacher(@PathVariable String id){
        boolean flag = teacherService.removeById(id);
        if(flag){
            return R.ok();
        }
        return R.failed();
    }

    //分页查询
    //current当前页
    // size每页记录数
    @GetMapping("pageTeacher/{current}/{size}")
    public R pageTeacher(@PathVariable long current,
                         @PathVariable long size){
        //创建new page对象
        Page<Teacher> pageTeacher = new Page<>(current,size);
        //调用方法的时候，底层封装好的，会把所有数据封装到pageTeacher对象里面
        teacherService.page(pageTeacher, null);

        long total = pageTeacher.getTotal();  //总记录数
        List<Teacher> record =  pageTeacher.getRecords();  //数据list集合

//        Map map = new HashMap();
//        map.put("total", total);
//        map.put("record", record);
//        return R.ok().data_sec(map);
        return R.ok().data("total", total).data("record", record);
    }

    //条件分页查询
    @PostMapping("pageTeacherCondition/{current}/{size}")
    public R pageTeacherQuery(@PathVariable long current, @PathVariable long size,
                              @RequestBody(required = false) TeacherQuery teacherQuery){
//        required = false  代表后面的teacherQuery可以是空
        //创建分页的page对象
        Page<Teacher> pageTeacher = new Page<>(current, size);

        //常见查询条件
        QueryWrapper<Teacher> wapper = new QueryWrapper<>();
        String name = teacherQuery.getName();
        Integer level = teacherQuery.getLevel();
        String gmtCreate = teacherQuery.getGmtCreate();
        String gmtModified = teacherQuery.getGmtModified();
        //判断查询条件，拼接sql
        if (!StringUtils.isEmpty(name)){
            wapper.like("name", name);
        }
        if (!StringUtils.isEmpty(level)){
            wapper.eq("level", level);
        }
        //字段名是要跟数据库里的字段名一样
        if (!StringUtils.isEmpty(gmtCreate)){
            wapper.ge("gmt_create",gmtCreate);
        }
        if (!StringUtils.isEmpty(gmtModified)){
            wapper.le("gmt_modified",gmtModified);
        }
        //排序
        wapper.orderByDesc("gmt_modified");

        // 查询
        teacherService.page(pageTeacher,wapper);
        long total = pageTeacher.getTotal();
        List<Teacher> record = pageTeacher.getRecords();

        return R.ok().data("total",total).data("record", record);
    }

    //添加讲师
    @PostMapping("addTeacher")
    public R addTeacher(@RequestBody Teacher teacher){
        boolean save = teacherService.save(teacher);
        if(save){
            return R.ok();
        }
        return R.failed();
    }

    //根据ID查询
    @GetMapping("getTeacher/{id}")
    public R getTeacher(@PathVariable String id){
        //这块跟Django的 try exception很像
//        try{
//            Integer a = 10 /0;
//        }catch (Exception e){
//            //手动抛出异常
//            throw new QianggeException(20001,"手动抛出异常正常");
//        }

        Teacher byId = teacherService.getById(id);
        return R.ok().data("teacher",byId);
    }

    //添加教师详情
    @PostMapping("updateTeacher")
    public R updateTeacher(@RequestBody Teacher teacher){
        boolean b = teacherService.updateById(teacher);
        if(b){
            return R.ok();
        }
        return R.failed();
    }


}

