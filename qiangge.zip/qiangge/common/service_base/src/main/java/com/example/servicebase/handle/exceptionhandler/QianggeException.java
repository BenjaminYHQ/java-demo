package com.example.servicebase.handle.exceptionhandler;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor  //有参数构造方法
@NoArgsConstructor  //无参数构造方法
public class QianggeException extends RuntimeException {
    private Integer code;  //状态吗
    private String msg;  //错误信息

}
