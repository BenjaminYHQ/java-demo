package com.example.edu.config;

import com.baomidou.mybatisplus.core.injector.ISqlInjector;
import com.baomidou.mybatisplus.extension.injector.LogicSqlInjector;
import com.baomidou.mybatisplus.extension.plugins.OptimisticLockerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.extension.plugins.PerformanceInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@MapperScan("com.example.edu.mapper")
public class EduConfig {
//    配置类 可以添加各种插件
    // 性能分析插件，
    // dev，test，pro环境，在配置中，配置环境状态

    @Bean
    @Profile({"dev", "test"})
    public PerformanceInterceptor performanceInterceptor(){
        PerformanceInterceptor performanceInterceptor = new PerformanceInterceptor();
        performanceInterceptor.setMaxTime(2000);  // 设置超过这个毫秒数的sql，不执行
        performanceInterceptor.setFormat(true);
        return performanceInterceptor;
    }

    //逻辑删除插件
    @Bean
    public ISqlInjector sqlInjector(){

        return new LogicSqlInjector();
    }

    //  乐观锁插件,根据版本号，谁先修改成功算谁的。
    @Bean
    public OptimisticLockerInterceptor optimisticLockerInterceptor(){

        return new OptimisticLockerInterceptor();
    }

    //  分页插件
    @Bean
    public PaginationInterceptor paginationInterceptor(){
        return new PaginationInterceptor();

    }

}
