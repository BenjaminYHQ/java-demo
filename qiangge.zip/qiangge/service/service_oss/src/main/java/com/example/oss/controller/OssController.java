package com.example.oss.controller;

import com.example.commonutils.R;
import com.example.oss.service.OssService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@CrossOrigin
@RequestMapping("/eduoss/fileoss")
public class OssController {


    //把service注入
    @Autowired
    private OssService ossService;

    @PostMapping("add/avator")
    //MultipartFile 取得file文件
    public R uploadOssFile(MultipartFile file){

        String url =  ossService.uploadFileAvatar(file);
        return R.ok().data("url",url);
    }

}
