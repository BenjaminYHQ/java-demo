package com.example.edu.mapper;

import com.example.edu.entity.Teacher;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * è®²å¸ˆ Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2020-07-27
 */
public interface TeacherMapper extends BaseMapper<Teacher> {

}
