package com.example.servicebase.handle.exceptionhandler;


import com.example.commonutils.R;
import lombok.extern.log4j.Log4j;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;


@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    //全局异常处理的方法
    // 指定出现什么异常,执行这个异常
    @ExceptionHandler({Exception.class})
    @ResponseBody  //为了返回数据
    public R error(Exception e){
        e.printStackTrace(); //打印出来
        return R.failed().message("异常处理中。。");
    }

    //特定异常处理
    @ExceptionHandler({ArithmeticException.class})
    @ResponseBody
    public R error(ArithmeticException e){
        e.printStackTrace();
        return R.failed().message("异常ArithmeticException处理中。。");
    }

    //自定义异常处理
    @ExceptionHandler({QianggeException.class})
    @ResponseBody
    public R error(QianggeException e){
        //把异常信息输入到log文件中
        log.error(e.getMsg());
        e.printStackTrace();
        return R.failed().code(e.getCode()).message(e.getMsg());
    }
}
