package com.example.commonutils;


import io.swagger.models.auth.In;

public interface ResultCode {
    public static Integer Success = 20000;  //成功
    public static Integer Failed = 20001;  //失败

}
