package com.example.edu.entity.vo;

import lombok.Data;

import java.util.Date;

@Data
public class TeacherQuery {
    private String name;

    private Integer level;

    private String gmtCreate;

    private String gmtModified;

}
