package com.example.oss.utils;


import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//当项目已启动，spring接口，spring加载之后，执行接口一个方法
@Component
public class ConstantPropertiesUtils implements InitializingBean {

    //读取配置文件内容
    @Value("${aliyun.oss.file.endpoint}")
    private String Endpoint;

    @Value("${aliyun.oss.file.keyid}")
    private String KeyId;

    @Value("${aliyun.oss.file.keysecret}")
    private String KeySecret;

    @Value("${aliyun.oss.file.bucketname}")
    private String BucketName;

    //定义公开静态常量
    public static String END_POIND;
    public static String ACCESS_KEY_ID;
    public static String ACCESS_KEY_SECRET;
    public static String BUCKET_NAME;

    //上面private的属性初始化完成以后，这个方法就会被调用
    @Override
    public void afterPropertiesSet() throws Exception {
        END_POIND = KeyId;
        ACCESS_KEY_ID = KeyId;
        ACCESS_KEY_SECRET = KeySecret;
        BUCKET_NAME = BucketName;
    }

}
